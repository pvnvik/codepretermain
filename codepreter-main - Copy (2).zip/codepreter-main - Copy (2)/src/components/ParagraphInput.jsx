import React, { useState } from "react";
import styles from "../style"; // Assuming you have a style import

const ParagraphInput = ({ onSubmit }) => {
  const [inputText, setInputText] = useState("");
  const [dropdown1Value, setDropdown1Value] = useState("");
  const [dropdown2Value, setDropdown2Value] = useState("");
  const [output, setOutput] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(inputText, dropdown1Value, dropdown2Value);
    setOutput(`Input Paragraph: ${inputText}\nDropdown 1: ${dropdown1Value}\nDropdown 2: ${dropdown2Value}`);
  };

  const handleInputChange = (e) => {
    setInputText(e.target.value);
  };

  const handleDropdown1Change = (e) => {
    setDropdown1Value(e.target.value);
  };

  const handleDropdown2Change = (e) => {
    setDropdown2Value(e.target.value);
  };

  return (
    <section id="paragraph-input" className="flex">
      <div className={`${styles.section} w-1/2 pr-8`}>
        <form onSubmit={handleSubmit} className="flex flex-col items-center">
          <textarea
            placeholder="Enter your paragraph here..."
            value={inputText}
            onChange={handleInputChange}
            className={`${styles.textarea} p-2 border border-gray-300 rounded-md mb-4`}
            rows={10}
            cols={50}
          />
          <div className="flex mb-4">
            <select
              value={dropdown1Value}
              onChange={handleDropdown1Change}
              className={`${styles.select} mr-4`}
            >
              <option value="">Select option 1</option>
              <option value="option1">Option 1</option>
              <option value="option2">Option 2</option>
              <option value="option3">Option 3</option>
            </select>
            <select
              value={dropdown2Value}
              onChange={handleDropdown2Change}
              className={styles.select}
            >
              <option value="">Select option 2</option>
              <option value="optionA">Option A</option>
              <option value="optionB">Option B</option>
              <option value="optionC">Option C</option>
            </select>
          </div>
          <button
            type="submit"
            className={`${styles.button} px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600`}
          >
            Submit
          </button>
        </form>
      </div>

      {output && (
        <div className={`${styles.section} w-1/2 pl-8`}>
          <h2 className="text-lg font-semibold mb-4">Output:</h2>
          <textarea
            className={`${styles.textarea} p-2 border border-gray-300 rounded-md`}
            value={output}
            readOnly
            rows={10}
            cols={50}
          />
        </div>
      )}
    </section>
  );
};

export default ParagraphInput;

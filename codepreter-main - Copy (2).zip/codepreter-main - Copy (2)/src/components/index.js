
import Navbar from "./Navbar";
import Business from "./Business";
import Footer from "./Footer";
import Hero from "./Hero";

export {
  Navbar,
  Business,
  Footer,
  Hero,
};
